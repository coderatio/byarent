<!-- Features -->
<h3 class="desc-headline">Features</h3>
<ul class="property-features checkboxes margin-top-0">
    <li>Air Conditioning</li>
    <li>Swimming Pool</li>
    <li>Central Heating</li>
    <li>Laundry Room</li>
    <li>Gym</li>
    <li>Alarm</li>
    <li>Window Covering</li>
    <li>Internet</li>
</ul>
