<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <!-- Basic Page Needs
    ================================================== -->
    <title><?php echo $__env->yieldContent('title'); ?> - Byarent platform</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/template/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/uikit/css/uikit.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/template/css/colors/red.css')); ?>" id="colors">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>" id="colors">

</head>

<body>
<!-- Wrapper -->
<div id="wrapper" style="<?php echo $__env->yieldContent('wrapper-style'); ?>">
    <!-- Header Container
    ================================================== -->
    <?php echo $__env->make('sections.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Header Container / End -->

    <!-- Banner
    ================================================== -->
    <?php echo $__env->yieldContent('before-content'); ?>

    <!-- Content
    ================================================== -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer
    ================================================ -->
    <?php echo $__env->make('sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>
<!-- Wrapper / End -->
</body>
</html>
