@extends('layouts.master')

@section('title', 'Houses')


@section('content')

@stop
