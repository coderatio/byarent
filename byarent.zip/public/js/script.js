$(document).ready(function () {
    $('.prevented-link').click((e) => {
        e.preventDefault();
    });
});
